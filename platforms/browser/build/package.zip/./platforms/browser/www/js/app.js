/**
 * myask Module
 *
 * Description
 */
var myask = angular.module('myask', ['ngRoute']);
myask.config(function($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl: "./templates/home.html",
            controller: 'HomeController'

        })
        .when("/register", {
            templateUrl: "./templates/register.html",
            controller: 'RegisterController'
        })

});



myask.controller('RegisterController', ['$scope', '$location', '$timeout', function($scope, $location, $timeout) {

    $scope.addInfoToDb = function() {

        $timeout(function() {
            $location.path('/');
        }, 3000);

    }

}]);
myask.controller('HomeController', ['$scope', '$location', '$timeout', function($scope, $location, $timeout) {

 	
    $scope.navigateToRegister = function() {
       
        
	        $timeout(function() {
            $location.path('/register');
        }, 300);
    }

}])
